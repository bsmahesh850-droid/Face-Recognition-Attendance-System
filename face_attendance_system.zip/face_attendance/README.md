# FaceLog — Face Recognition Attendance System

A production-quality, browser-based attendance management system that uses facial recognition to automatically detect and log attendance from a webcam feed.

---

## Features

- **Real-Time Face Detection** — Live webcam feed with bounding boxes and name labels
- **Automatic Attendance Logging** — Marks attendance the moment a face is recognized
- **Smart Deduplication** — Each person is logged only once per calendar day
- **Face Registration** — Add users via webcam capture or image upload
- **Web Dashboard** — Clean, dark-themed UI with live stats
- **Attendance Records** — Filterable table with date and name search
- **CSV Export** — Download filtered or full attendance records
- **Unknown Face Labeling** — Unrecognized faces are labeled "Unknown"
- **Error Handling** — Graceful handling of camera errors, missing faces, etc.

---

## Tech Stack

| Layer       | Technology                    |
|-------------|-------------------------------|
| Backend     | Python 3.10+, Flask           |
| Recognition | `face_recognition` (dlib)     |
| Vision      | OpenCV                        |
| Database    | SQLite (via `sqlite3`)        |
| Frontend    | HTML, CSS, Vanilla JS         |
| Fonts       | Syne + DM Mono (Google Fonts) |

---

## Project Structure

```
face_attendance/
│
├── app.py                  # Flask application & routes
├── requirements.txt        # Python dependencies
├── README.md
│
├── database/
│   └── attendance.db       # SQLite database (auto-created)
│
├── known_faces/            # Registered face images (JPG)
│
├── static/
│   ├── style.css           # Dark industrial theme
│   └── script.js           # Webcam, recognition loop, UI
│
├── templates/
│   ├── index.html          # Home + live recognition panel
│   ├── register.html       # Face registration page
│   └── attendance.html     # Records table + filters
│
└── utils/
    └── face_utils.py       # Core face recognition & DB logic
```

---

## Installation

### Prerequisites

- Python 3.10 or higher
- `cmake` and C++ build tools (required by `dlib`):
  - **Ubuntu/Debian:** `sudo apt install cmake build-essential`
  - **macOS:** `brew install cmake`
  - **Windows:** Install [Visual Studio Build Tools](https://visualstudio.microsoft.com/downloads/)

### Steps

```bash
# 1. Clone or download the project
cd face_attendance

# 2. (Optional) Create a virtual environment
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the application
python app.py
```

Open your browser at: **http://127.0.0.1:5000**

---

## How to Use

### 1. Register a Face
- Go to **Register** in the nav bar
- Enter the person's full name
- Use **Webcam Capture** (open camera → capture photo) or **Upload Image**
- Click **Register Face**

### 2. Take Attendance
- Go to **Home**
- Click **Start Attendance** or **Start Camera**
- The system scans every 2 seconds
- Recognized faces appear in the detection log with a ✓ badge when first marked

### 3. View Records
- Go to **Records**
- Filter by date or name
- Click **Export CSV** to download

---

## Screenshots

| Home / Live Recognition | Register Face | Attendance Records |
|------------------------|---------------|--------------------|
| _(screenshot)_         | _(screenshot)_ | _(screenshot)_    |

---

## Configuration

Edit the constants in `utils/face_utils.py`:

| Constant | Default | Description |
|----------|---------|-------------|
| `RECOGNIZE_INTERVAL_MS` | `2000` | ms between auto-scans (in `script.js`) |
| Distance threshold | `0.5` | Face match sensitivity (lower = stricter) |

---

## Future Improvements

- [ ] Multi-camera support
- [ ] Email/SMS attendance notifications
- [ ] Role-based access control (admin/viewer)
- [ ] Face liveness detection (anti-spoofing)
- [ ] Department/group filtering
- [ ] Attendance reports with charts
- [ ] Docker deployment support
- [ ] REST API with token authentication

---

## License

MIT License — free to use, modify, and distribute.
