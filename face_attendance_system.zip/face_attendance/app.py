"""
Face Recognition Attendance System
Main Flask application entry point
"""

import os
import cv2
import base64
import threading
from datetime import datetime
from flask import Flask, render_template, request, jsonify, Response, send_file
from utils.face_utils import (
    load_known_faces,
    recognize_faces_in_frame,
    register_new_face,
    get_all_attendance,
    export_attendance_csv,
    get_attendance_stats,
    get_registered_users,
    delete_user
)

app = Flask(__name__)

# Global state for webcam stream
camera_lock = threading.Lock()
current_frame = None
current_detections = []
is_streaming = False
stream_thread = None

# ─────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────

@app.route('/')
def index():
    """Home page with system overview and quick stats."""
    stats = get_attendance_stats()
    return render_template('index.html', stats=stats)


@app.route('/register')
def register():
    """Face registration page."""
    users = get_registered_users()
    return render_template('register.html', users=users)


@app.route('/attendance')
def attendance():
    """Attendance records page."""
    date_filter = request.args.get('date', '')
    name_filter = request.args.get('name', '')
    records = get_all_attendance(date_filter=date_filter, name_filter=name_filter)
    return render_template('attendance.html', records=records,
                           date_filter=date_filter, name_filter=name_filter)


# ─────────────────────────────────────────────
# API Endpoints
# ─────────────────────────────────────────────

@app.route('/api/register', methods=['POST'])
def api_register():
    """Register a new face from uploaded image or webcam capture."""
    try:
        name = request.form.get('name', '').strip()
        if not name:
            return jsonify({'success': False, 'message': 'Name is required.'}), 400

        # Sanitize name
        name = name.replace('/', '_').replace('\\', '_')

        if 'image' in request.files:
            # File upload
            file = request.files['image']
            if file.filename == '':
                return jsonify({'success': False, 'message': 'No file selected.'}), 400
            image_data = file.read()
            success, message = register_new_face(name, image_data=image_data)
        elif 'frame' in request.form:
            # Base64 webcam capture
            frame_data = request.form['frame']
            if ',' in frame_data:
                frame_data = frame_data.split(',')[1]
            image_data = base64.b64decode(frame_data)
            success, message = register_new_face(name, image_data=image_data)
        else:
            return jsonify({'success': False, 'message': 'No image provided.'}), 400

        # Reload known faces after registration
        if success:
            load_known_faces()

        return jsonify({'success': success, 'message': message})

    except Exception as e:
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@app.route('/api/recognize', methods=['POST'])
def api_recognize():
    """Recognize faces in a submitted frame and mark attendance."""
    try:
        frame_data = request.form.get('frame', '')
        if not frame_data:
            return jsonify({'success': False, 'message': 'No frame data.'}), 400

        if ',' in frame_data:
            frame_data = frame_data.split(',')[1]

        image_data = base64.b64decode(frame_data)
        results = recognize_faces_in_frame(image_data)
        return jsonify({'success': True, 'results': results})

    except Exception as e:
        return jsonify({'success': False, 'message': f'Recognition error: {str(e)}'}), 500


@app.route('/api/attendance')
def api_attendance():
    """Return attendance records as JSON."""
    date_filter = request.args.get('date', '')
    name_filter = request.args.get('name', '')
    records = get_all_attendance(date_filter=date_filter, name_filter=name_filter)
    return jsonify({'success': True, 'records': records})


@app.route('/api/stats')
def api_stats():
    """Return live stats for dashboard."""
    stats = get_attendance_stats()
    return jsonify({'success': True, 'stats': stats})


@app.route('/api/users')
def api_users():
    """Return list of registered users."""
    users = get_registered_users()
    return jsonify({'success': True, 'users': users})


@app.route('/api/delete_user', methods=['POST'])
def api_delete_user():
    """Delete a registered user and their face data."""
    name = request.form.get('name', '').strip()
    if not name:
        return jsonify({'success': False, 'message': 'Name required.'}), 400
    success, message = delete_user(name)
    if success:
        load_known_faces()
    return jsonify({'success': success, 'message': message})


@app.route('/api/download_csv')
def download_csv():
    """Export attendance records as CSV download."""
    date_filter = request.args.get('date', '')
    csv_path = export_attendance_csv(date_filter=date_filter)
    return send_file(csv_path, as_attachment=True,
                     download_name=f'attendance_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv',
                     mimetype='text/csv')


# ─────────────────────────────────────────────
# App Startup
# ─────────────────────────────────────────────

if __name__ == '__main__':
    print("=" * 55)
    print("  Face Recognition Attendance System")
    print("  Loading known faces...")
    load_known_faces()
    print("  Starting Flask server at http://127.0.0.1:5000")
    print("=" * 55)
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
