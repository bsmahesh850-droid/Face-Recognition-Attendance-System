/**
 * FaceLog — Face Recognition Attendance System
 * script.js: Webcam handling, recognition loop, and UI updates
 */

// ─────────────────────────────────────────────
// State
// ─────────────────────────────────────────────
let webcamStream   = null;
let isRecognizing  = false;
let recognizeTimer = null;
const RECOGNIZE_INTERVAL_MS = 2000; // auto-scan every 2 seconds

// ─────────────────────────────────────────────
// Camera Controls (Home Page)
// ─────────────────────────────────────────────

/**
 * Toggle webcam on/off for the attendance panel.
 */
async function toggleCamera() {
  if (webcamStream) {
    stopCamera();
  } else {
    await startCamera();
  }
}

async function startCamera() {
  const video       = document.getElementById('video-feed');
  const overlay     = document.getElementById('overlay-canvas');
  const placeholder = document.getElementById('camera-placeholder');
  const btn         = document.getElementById('cam-toggle-btn');
  const snapBtn     = document.getElementById('snapshot-btn');
  const statusEl    = document.getElementById('cam-status');

  if (!video) return;

  try {
    webcamStream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' }
    });

    video.srcObject = webcamStream;
    video.style.display = 'block';
    if (overlay) overlay.style.display = 'block';
    if (placeholder) placeholder.style.display = 'none';
    if (statusEl)  statusEl.style.display = 'flex';

    if (btn) { btn.innerHTML = '<span class="btn-icon">■</span> Stop Camera'; }
    if (snapBtn) snapBtn.style.display = 'inline-flex';

    // Start auto-recognition loop
    isRecognizing = true;
    recognizeLoop();

  } catch (err) {
    addLogEntry('Camera error: ' + err.message, 'error');
    alert('Could not access camera: ' + err.message);
  }
}

function stopCamera() {
  if (webcamStream) {
    webcamStream.getTracks().forEach(t => t.stop());
    webcamStream = null;
  }

  isRecognizing = false;
  clearTimeout(recognizeTimer);

  const video       = document.getElementById('video-feed');
  const overlay     = document.getElementById('overlay-canvas');
  const placeholder = document.getElementById('camera-placeholder');
  const btn         = document.getElementById('cam-toggle-btn');
  const snapBtn     = document.getElementById('snapshot-btn');
  const statusEl    = document.getElementById('cam-status');

  if (video)       { video.style.display = 'none'; }
  if (overlay)     { overlay.style.display = 'none'; clearCanvas(); }
  if (placeholder) { placeholder.style.display = 'flex'; }
  if (statusEl)    { statusEl.style.display = 'none'; }
  if (btn)         { btn.innerHTML = '<span class="btn-icon">▶</span> Start Camera'; }
  if (snapBtn)     { snapBtn.style.display = 'none'; }
}

// ─────────────────────────────────────────────
// Recognition Loop
// ─────────────────────────────────────────────

function recognizeLoop() {
  if (!isRecognizing || !webcamStream) return;
  recognizeFrame().finally(() => {
    if (isRecognizing) {
      recognizeTimer = setTimeout(recognizeLoop, RECOGNIZE_INTERVAL_MS);
    }
  });
}

/**
 * Capture current video frame, send to /api/recognize, draw results.
 */
async function recognizeFrame() {
  const video = document.getElementById('video-feed');
  if (!video || video.readyState < 2) return;

  const frame = captureFrame(video);
  if (!frame) return;

  try {
    const formData = new FormData();
    formData.append('frame', frame);

    const res  = await fetch('/api/recognize', { method: 'POST', body: formData });
    const data = await res.json();

    if (data.success && data.results) {
      drawDetections(video, data.results);
      updateLog(data.results);
      refreshStats();
    }
  } catch (err) {
    console.warn('[FaceLog] Recognition request failed:', err);
  }
}

/** Manual snapshot trigger (button) */
function takeSnapshot() {
  recognizeFrame();
}

// ─────────────────────────────────────────────
// Canvas Overlay
// ─────────────────────────────────────────────

function captureFrame(videoEl) {
  try {
    const canvas = document.createElement('canvas');
    canvas.width  = videoEl.videoWidth  || 640;
    canvas.height = videoEl.videoHeight || 480;
    canvas.getContext('2d').drawImage(videoEl, 0, 0);
    return canvas.toDataURL('image/jpeg', 0.8);
  } catch (e) {
    console.warn('Frame capture failed:', e);
    return null;
  }
}

function drawDetections(videoEl, results) {
  const overlay = document.getElementById('overlay-canvas');
  if (!overlay) return;

  const vw = videoEl.clientWidth  || videoEl.videoWidth  || 640;
  const vh = videoEl.clientHeight || videoEl.videoHeight || 480;
  const ow = videoEl.videoWidth   || 640;
  const oh = videoEl.videoHeight  || 480;

  overlay.width  = vw;
  overlay.height = vh;

  const ctx    = overlay.getContext('2d');
  const scaleX = vw / ow;
  const scaleY = vh / oh;

  ctx.clearRect(0, 0, vw, vh);

  results.forEach(det => {
    const { top, right, bottom, left } = det.location;
    const x = left  * scaleX;
    const y = top   * scaleY;
    const w = (right  - left) * scaleX;
    const h = (bottom - top)  * scaleY;

    const isKnown  = det.name !== 'Unknown';
    const color    = isKnown ? '#00e5a0' : '#ff4757';
    const labelTxt = isKnown
      ? `${det.name} (${det.confidence}%)`
      : 'Unknown';

    // Box
    ctx.strokeStyle = color;
    ctx.lineWidth   = 2;
    ctx.strokeRect(x, y, w, h);

    // Corner accents
    const cs = 12;
    ctx.lineWidth = 3;
    [[x, y, cs, 0, 0, cs], [x+w, y, -cs, 0, 0, cs],
     [x, y+h, cs, 0, 0, -cs], [x+w, y+h, -cs, 0, 0, -cs]].forEach(([px, py, dx1, dy1, dx2, dy2]) => {
      ctx.beginPath();
      ctx.moveTo(px + dx1, py + dy1);
      ctx.lineTo(px, py);
      ctx.lineTo(px + dx2, py + dy2);
      ctx.stroke();
    });

    // Label background
    ctx.font      = 'bold 12px "DM Mono", monospace';
    const tw      = ctx.measureText(labelTxt).width;
    const lh      = 22;
    const lx      = x;
    const ly      = y > lh + 4 ? y - lh - 4 : y + h + 4;

    ctx.fillStyle = color + 'cc';
    ctx.fillRect(lx, ly, tw + 12, lh);
    ctx.fillStyle = '#000';
    ctx.fillText(labelTxt, lx + 6, ly + 15);
  });
}

function clearCanvas() {
  const overlay = document.getElementById('overlay-canvas');
  if (overlay) overlay.getContext('2d').clearRect(0, 0, overlay.width, overlay.height);
}

// ─────────────────────────────────────────────
// Detection Log
// ─────────────────────────────────────────────

const seenThisSession = new Set();

function updateLog(results) {
  if (!results || results.length === 0) return;
  const container = document.getElementById('log-entries');
  if (!container) return;

  // Remove empty state
  const emptyEl = container.querySelector('.log-empty');
  if (emptyEl) emptyEl.remove();

  results.forEach(det => {
    const key = `${det.name}-${det.marked}`;
    if (det.name === 'Unknown' || seenThisSession.has(key + Date.now().toString().slice(0, -4))) return;
    seenThisSession.add(key + Date.now().toString().slice(0, -4));
    addLogEntry(det);
  });
}

function addLogEntry(det) {
  if (typeof det === 'string') {
    // Error string
    return;
  }
  const container = document.getElementById('log-entries');
  if (!container) return;

  const isKnown  = det.name !== 'Unknown';
  const typeClass = det.marked ? 'marked' : (isKnown ? 'known' : 'unknown');
  const badge     = det.marked ? 'NEW ✓' : (isKnown ? `${det.confidence}%` : 'UNKNOWN');
  const badgeClass = det.marked ? 'new' : (isKnown ? '' : 'unk');
  const now       = new Date().toLocaleTimeString();

  const entry = document.createElement('div');
  entry.className = `log-entry ${typeClass}`;
  entry.innerHTML = `
    <div>
      <div class="log-name">${escapeHtml(det.name)}</div>
      <div class="log-time">${now}</div>
    </div>
    <span class="log-badge ${badgeClass}">${badge}</span>
  `;

  container.insertBefore(entry, container.firstChild);

  // Keep max 50 entries
  const entries = container.querySelectorAll('.log-entry');
  if (entries.length > 50) entries[entries.length - 1].remove();
}

function clearLog() {
  const container = document.getElementById('log-entries');
  if (!container) return;
  container.innerHTML = '<div class="log-empty">Log cleared.</div>';
  seenThisSession.clear();
}

// ─────────────────────────────────────────────
// Stats Refresh
// ─────────────────────────────────────────────

async function refreshStats() {
  try {
    const res  = await fetch('/api/stats');
    const data = await res.json();
    if (!data.success) return;
    const s = data.stats;

    setText('stat-today',  s.today_count);
    setText('stat-faces',  s.registered_faces);
    setText('stat-total',  s.total_records);
    setText('stat-days',   s.total_days);
  } catch (e) { /* silent */ }
}

function setText(id, val) {
  const el = document.getElementById(id);
  if (el && el.textContent !== String(val)) {
    el.textContent = val;
    el.style.transform = 'scale(1.15)';
    setTimeout(() => { el.style.transform = 'scale(1)'; el.style.transition = 'transform 0.2s'; }, 200);
  }
}

// ─────────────────────────────────────────────
// Utility
// ─────────────────────────────────────────────

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Smooth scroll for "Start Attendance" hero button
document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('start-btn');
  if (startBtn) {
    startBtn.addEventListener('click', (e) => {
      const target = document.getElementById('attendance-panel');
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
        setTimeout(() => startCamera(), 600);
      }
    });
  }
});
