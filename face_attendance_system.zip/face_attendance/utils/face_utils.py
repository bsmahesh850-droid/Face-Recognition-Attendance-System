"""
utils/face_utils.py
Core face recognition, registration, and attendance logic.
"""

import os
import io
import csv
import sqlite3
import numpy as np
from PIL import Image
from datetime import datetime, date
import face_recognition

# ─────────────────────────────────────────────
# Paths
# ─────────────────────────────────────────────

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KNOWN_FACES_DIR = os.path.join(BASE_DIR, 'known_faces')
DATABASE_DIR = os.path.join(BASE_DIR, 'database')
DB_PATH = os.path.join(DATABASE_DIR, 'attendance.db')
CSV_EXPORT_PATH = os.path.join(DATABASE_DIR, 'attendance_export.csv')

os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
os.makedirs(DATABASE_DIR, exist_ok=True)

# ─────────────────────────────────────────────
# In-memory store for known face encodings
# ─────────────────────────────────────────────

known_face_encodings = []
known_face_names = []


# ─────────────────────────────────────────────
# Database Initialization
# ─────────────────────────────────────────────

def init_db():
    """Create the attendance table if it doesn't exist."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            date        TEXT    NOT NULL,
            time        TEXT    NOT NULL,
            status      TEXT    DEFAULT 'Present',
            created_at  TEXT    DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()


init_db()


# ─────────────────────────────────────────────
# Known Faces Management
# ─────────────────────────────────────────────

def load_known_faces():
    """
    Scan the known_faces directory and build in-memory
    encodings for all registered users.
    """
    global known_face_encodings, known_face_names
    known_face_encodings = []
    known_face_names = []

    if not os.path.exists(KNOWN_FACES_DIR):
        return

    for filename in os.listdir(KNOWN_FACES_DIR):
        if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
            filepath = os.path.join(KNOWN_FACES_DIR, filename)
            try:
                image = face_recognition.load_image_file(filepath)
                encodings = face_recognition.face_encodings(image)
                if encodings:
                    # Strip extension for name
                    name = os.path.splitext(filename)[0]
                    known_face_encodings.append(encodings[0])
                    known_face_names.append(name)
            except Exception as e:
                print(f"[WARNING] Could not load {filename}: {e}")

    print(f"[INFO] Loaded {len(known_face_names)} known face(s): {known_face_names}")


def register_new_face(name: str, image_data: bytes) -> tuple[bool, str]:
    """
    Register a new face from raw image bytes.
    Returns (success: bool, message: str).
    """
    try:
        # Decode image
        pil_image = Image.open(io.BytesIO(image_data)).convert('RGB')
        np_image = np.array(pil_image)

        # Detect faces
        encodings = face_recognition.face_encodings(np_image)
        if not encodings:
            return False, "No face detected in the image. Please use a clear, well-lit photo."

        if len(encodings) > 1:
            return False, "Multiple faces detected. Please use a photo with only one person."

        # Save image
        save_path = os.path.join(KNOWN_FACES_DIR, f"{name}.jpg")
        pil_image.save(save_path, 'JPEG', quality=95)

        return True, f"✓ '{name}' registered successfully!"

    except Exception as e:
        return False, f"Registration failed: {str(e)}"


def get_registered_users() -> list[dict]:
    """Return a list of registered users with metadata."""
    users = []
    if not os.path.exists(KNOWN_FACES_DIR):
        return users

    for filename in os.listdir(KNOWN_FACES_DIR):
        if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
            name = os.path.splitext(filename)[0]
            filepath = os.path.join(KNOWN_FACES_DIR, filename)
            stat = os.stat(filepath)
            users.append({
                'name': name,
                'filename': filename,
                'registered_at': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M'),
                'image_path': f'/known_faces/{filename}'
            })

    return sorted(users, key=lambda x: x['registered_at'], reverse=True)


def delete_user(name: str) -> tuple[bool, str]:
    """Remove a registered user's face image."""
    for ext in ['.jpg', '.jpeg', '.png']:
        filepath = os.path.join(KNOWN_FACES_DIR, f"{name}{ext}")
        if os.path.exists(filepath):
            os.remove(filepath)
            return True, f"User '{name}' deleted."
    return False, f"User '{name}' not found."


# ─────────────────────────────────────────────
# Face Recognition & Attendance
# ─────────────────────────────────────────────

def recognize_faces_in_frame(image_data: bytes) -> list[dict]:
    """
    Recognize faces in a frame and mark attendance.
    Returns a list of detection results.
    """
    results = []

    try:
        pil_image = Image.open(io.BytesIO(image_data)).convert('RGB')
        np_image = np.array(pil_image)

        # Resize for faster processing (scale down to 25%)
        small = np_image[::4, ::4]

        face_locations = face_recognition.face_locations(small)
        face_encodings = face_recognition.face_encodings(small, face_locations)

        today = date.today().isoformat()
        now = datetime.now().strftime('%H:%M:%S')

        for encoding, location in zip(face_encodings, face_locations):
            name = "Unknown"
            confidence = 0.0
            marked = False

            if known_face_encodings:
                distances = face_recognition.face_distance(known_face_encodings, encoding)
                best_idx = np.argmin(distances)
                best_dist = distances[best_idx]

                # Threshold: distance < 0.5 = good match
                if best_dist < 0.5:
                    name = known_face_names[best_idx]
                    confidence = round((1 - best_dist) * 100, 1)

                    # Mark attendance only once per day
                    if not _already_marked(name, today):
                        _mark_attendance(name, today, now)
                        marked = True

            # Scale location back up (×4)
            top, right, bottom, left = [v * 4 for v in location]

            results.append({
                'name': name,
                'confidence': confidence,
                'marked': marked,
                'location': {'top': top, 'right': right, 'bottom': bottom, 'left': left}
            })

    except Exception as e:
        print(f"[ERROR] Recognition failed: {e}")

    return results


def _already_marked(name: str, today: str) -> bool:
    """Check if attendance already recorded for this person today."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        'SELECT id FROM attendance WHERE name=? AND date=?',
        (name, today)
    )
    result = cursor.fetchone()
    conn.close()
    return result is not None


def _mark_attendance(name: str, today: str, now: str):
    """Insert attendance record into the database."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO attendance (name, date, time, status) VALUES (?, ?, ?, ?)',
        (name, today, now, 'Present')
    )
    conn.commit()
    conn.close()
    print(f"[ATTENDANCE] Marked: {name} @ {today} {now}")


# ─────────────────────────────────────────────
# Attendance Queries
# ─────────────────────────────────────────────

def get_all_attendance(date_filter: str = '', name_filter: str = '') -> list[dict]:
    """Fetch attendance records with optional filtering."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    query = 'SELECT * FROM attendance WHERE 1=1'
    params = []

    if date_filter:
        query += ' AND date = ?'
        params.append(date_filter)

    if name_filter:
        query += ' AND name LIKE ?'
        params.append(f'%{name_filter}%')

    query += ' ORDER BY date DESC, time DESC'
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]


def get_attendance_stats() -> dict:
    """Return aggregate stats for the dashboard."""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    today = date.today().isoformat()

    cursor.execute('SELECT COUNT(*) FROM attendance')
    total = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM attendance WHERE date = ?', (today,))
    today_count = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(DISTINCT name) FROM attendance')
    unique_people = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(DISTINCT date) FROM attendance')
    total_days = cursor.fetchone()[0]

    conn.close()

    return {
        'total_records': total,
        'today_count': today_count,
        'unique_people': unique_people,
        'total_days': total_days,
        'registered_faces': len(known_face_names),
        'today_date': datetime.now().strftime('%B %d, %Y')
    }


def export_attendance_csv(date_filter: str = '') -> str:
    """Write attendance records to CSV and return file path."""
    records = get_all_attendance(date_filter=date_filter)

    with open(CSV_EXPORT_PATH, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['id', 'name', 'date', 'time', 'status', 'created_at'])
        writer.writeheader()
        writer.writerows(records)

    return CSV_EXPORT_PATH
